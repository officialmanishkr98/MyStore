package com.lcwd.store.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.lcwd.store.entities.Product;

public interface ProductRepository extends JpaRepository<Product, String>{

	Product findByColour(String colour);
	List<Product> findByModelContaining(String model);
	
	@Query("select p from Product p where p.price > :keyword")
	List<Product> findProductWithPriceInRange(int keyword);
}
